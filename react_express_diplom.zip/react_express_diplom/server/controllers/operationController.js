const { Operations } = require('../models/models');
const ApiError = require('../error/ApiError');

class operationController {
    // Создание операции
    async create(req, res, next) {
        try {
            const { 
                type, // Тип операции (приход/расход)
                date, // Дата операции
                itemId, // ID товара
                skladId, // ID склада
                quantity // Количество товаров в операции
            } = req.body;

            const operation = await Operations.create({
                type,
                date,
                itemId,
                skladId,
                quantity,
            });

            return res.json(operation);
        } catch (error) {
            next(ApiError.internal('Ошибка при создании операции'));
        }
    }

    // Получение всех операций
    async getAll(req, res, next) {
        try {
            const operations = await Operations.findAll();
            return res.json(operations);
        } catch (error) {
            next(ApiError.internal('Ошибка при получении операций'));
        }
    }
}

module.exports = new operationController();
