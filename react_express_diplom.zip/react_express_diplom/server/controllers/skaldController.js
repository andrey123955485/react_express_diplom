const {Sklad} = require('../models/models')
const ApiError = require('../error/ApiError')

class skladController {
    async create(req, res) {
        const {location} = req.body
        const sklad = await Sklad.create({location})
        return res.json(sklad)
    }
    async getAll(req, res) {
        const sklads = await Sklad.findAll()
        return res.json(sklads)
    }
}

module.exports = new skladController()