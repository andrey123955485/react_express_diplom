class skladController {
    async create(req, res) {
        
    }
    async getAll(req, res) {

    }
}

module.exports = new skladController()