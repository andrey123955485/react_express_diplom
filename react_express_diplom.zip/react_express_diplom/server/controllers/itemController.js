class itemController {
    async create(req, res) {
        
    }
    async getAll(req, res) {

    }
}

module.exports = new itemController()