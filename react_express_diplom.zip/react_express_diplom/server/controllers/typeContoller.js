const {Type} = require('../models/models')
const ApiError = require('../error/ApiError')

class typeController {
    async create(req, res) {
        
    }
    async getAll(req, res) {

    }
}

module.exports = new typeController()