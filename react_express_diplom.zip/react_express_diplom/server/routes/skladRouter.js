const Router = require('express')
const skaldController = require('../controllers/skaldController')
const router = new Router()

router.post('/', skaldController.create)
router.get('/', skaldController.getAll)

module.exports = router