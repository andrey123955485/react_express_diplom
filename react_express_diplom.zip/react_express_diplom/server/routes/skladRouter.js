const Router = require('express')
const skladController = require('../controllers/skladController')
const router = new Router()

router.post('/', skladController.create)
router.get('/', skladController.getAll)

module.exports = router