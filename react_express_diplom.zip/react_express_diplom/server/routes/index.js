const Router = require('express')
const router = new Router()

const userRouter = require('./userRouter')
const skladRouter = require('./skladRouter')
const itemRouter = require('./itemRouter')
const typeRouter = require('./typeRouter')


router.use('/user', userRouter)
router.use('/sklad', skladRouter)
router.use('/item', itemRouter)
router.use('/type', typeRouter)


module.exports = router