const sequelize = require('../db')
const {DataTypes} = require('sequelize')

const User = sequelize.define( 'user', {
    id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
    email: {type: DataTypes.STRING, unique: true},
    password: {type: DataTypes.STRING},
    role: {type: DataTypes.STRING, defaultValue: "ADMIN"},
})

const Sklad = sequelize.define('sklad', {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    location: { type: DataTypes.STRING, allowNull: true }, // Для хранения адреса или города склада
    capacity: { type: DataTypes.INTEGER, allowNull: true } // Возможная вместимость склада
});


const SkladItem = sequelize.define('sklad_item', {
    skladId: { type: DataTypes.INTEGER, references: { model: 'sklads', key: 'id' } },
    itemId: { type: DataTypes.INTEGER, references: { model: 'items', key: 'id' } },
    quantity: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 }, // количество на складе
});

const Items = sequelize.define('items', {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    name: { type: DataTypes.STRING, allowNull: false },
    price: { type: DataTypes.DECIMAL(10, 2), allowNull: false },
    img: { type: DataTypes.STRING, allowNull: true }, // путь к изображению
    weight: { type: DataTypes.FLOAT, allowNull: true },
    stockQuantity: { type: DataTypes.INTEGER, allowNull: true, defaultValue: 0 }, // добавлено для учета запасов
    expiryDate: { type: DataTypes.DATE, allowNull: true }, // срок годности
    typeId: { type: DataTypes.INTEGER, allowNull: false, references: { model: 'types', key: 'id' } }, // связь с таблицей type
});

const ItemInfo = sequelize.define('item_info', {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    itemId: { type: DataTypes.INTEGER, allowNull: false, references: { model: 'items', key: 'id' } }, // связь с таблицей items
    title: { type: DataTypes.STRING, allowNull: false },
    description: { type: DataTypes.TEXT, allowNull: true },
});

const Type = sequelize.define('type', {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    name: { type: DataTypes.STRING, unique: true, allowNull: false },
    parentId: { type: DataTypes.INTEGER, allowNull: true, references: { model: 'types', key: 'id' } }, // для создания иерархии категорий
});

User.hasOne(Sklad)
Sklad.belongsTo(User)

Type.hasMany(Items)
Items.belongsTo(Type)

Items.hasOne(ItemInfo)
ItemInfo.belongsTo(Items)

Sklad.belongsToMany(Items, { through: SkladItem });
Items.belongsToMany(Sklad, { through: SkladItem });

module.exports = {
    User,
    Sklad,
    SkladItem,
    Items,
    ItemInfo,
    Type
}