const sequelize = require('../db')
const {DataTypes} = require('sequelize')

const User = sequelize.define( 'user', {
    id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
    login: {type: DataTypes.STRING, unique: true, allowNull: false},
    password: {type: DataTypes.STRING, allowNull: false},
    role: {type: DataTypes.STRING, defaultValue: "ADMIN"},
})

const Sklad = sequelize.define('sklad', {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    location: { type: DataTypes.STRING, allowNull: false }, // Для хранения адреса или города склада
    capacity: { type: DataTypes.INTEGER, allowNull: false } // Возможная вместимость склада
});


const SkladItem = sequelize.define('sklad_item', {
    skladId: { type: DataTypes.INTEGER, references: { model: 'sklads', key: 'id' } },
    itemId: { type: DataTypes.INTEGER, references: { model: 'items', key: 'id' } },
    quantity: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 }, // количество на складе
});

const Items = sequelize.define('items', {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    name: { type: DataTypes.STRING, allowNull: false },
    price: { type: DataTypes.DECIMAL(10, 2), allowNull: false },
    img: { type: DataTypes.STRING, allowNull: true }, // путь к изображению
    weight: { type: DataTypes.FLOAT, allowNull: true },
    stockQuantity: { type: DataTypes.INTEGER, allowNull: true, defaultValue: 0 }, // добавлено для учета запасов
    expiryDate: { type: DataTypes.DATE, allowNull: true }, // срок годности
    categoryId: { type: DataTypes.INTEGER, allowNull: false, references: { model: 'categories', key: 'id' } }, // связь с таблицей type
    skladId: { type: DataTypes.INTEGER, allowNull: true, references: { model: 'sklads', key: 'id' } }, // Проверьте наличие этого поля
});

const ItemInfo = sequelize.define('item_info', {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    itemId: { type: DataTypes.INTEGER, allowNull: false, references: { model: 'items', key: 'id' } }, // связь с таблицей items
    title: { type: DataTypes.STRING, allowNull: false },
    description: { type: DataTypes.TEXT, allowNull: true },
});

const Category = sequelize.define('category', {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    name: { type: DataTypes.STRING, unique: true, allowNull: false },
    parentId: { type: DataTypes.INTEGER, allowNull: true, references: { model: 'categories', key: 'id' } }
});

const Operatinos = sequelize.define('operations', {
    id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
    skladId: {type: DataTypes.INTEGER, references: {model: 'sklads', key: 'id'}, allowNull: false},
    itemId: {type: DataTypes.INTEGER, references: {model: 'items', key: 'id'}, allowNull: false},
    operationType: {type: DataTypes.ENUM('приход', 'расход'), allowNull: false},
    quantity: {type: DataTypes.INTEGER, allowNull: false},
    date: {type: DataTypes.DATE, allowNull: false, defaultValue: DataTypes.NOW},
});

const Reports = sequelize.define('reports', {
    id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
    skladId: {type: DataTypes.INTEGER, references: {model: 'sklads', key: 'id'}, allowNull: false},
    dateform: {type: DataTypes.DATE, allowNull: false},
    dateTo: {type: DataTypes.DATE, allowNull: false},
    filepath: {type: DataTypes.STRING, allowNull: true},
});

User.hasOne(Sklad);
Sklad.belongsTo(User);

Category.hasMany(Items);
Items.belongsTo(Category);

Items.hasOne(ItemInfo);
ItemInfo.belongsTo(Items);

Sklad.belongsToMany(Items, { through: SkladItem });
Items.belongsToMany(Sklad, { through: SkladItem });

Sklad.hasMany(Operatinos);
Operatinos.belongsTo(Sklad);

Items.hasMany(Operatinos);
Operatinos.belongsTo(Items);

Sklad.hasMany(Reports);
Reports.belongsTo(Sklad);

module.exports = {
    User,
    Sklad,
    SkladItem,
    Items,
    ItemInfo,
    Operatinos,
    Reports,
    Category,
}