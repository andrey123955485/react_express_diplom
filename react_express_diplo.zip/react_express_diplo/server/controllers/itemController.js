const { Items } = require("../models/models")
const uuid = require('uuid')
const path = require('path')
const ApiError = require('../error/ApiError')
class itemController {
    async create(req, res, next) {
        try{
        const{name, price, weight, stockQuantity, expiryDate, categoryId, skladId} = req.body
        const {img} = req.files
        let filename = uuid.v4() + '.jpg'
        img.mv(path.resolve(__dirname, '..', 'static', filename))
        const item = await Items.create({name, price, weight, stockQuantity, expiryDate, categoryId, skladId, img: filename})

        return res.json(item)
        } catch(e){
            next(ApiError.badRequest(e.message))
        }
    }
    async getAll(req, res) {
        const {categoryId, skladId} = req.query
        let items;
        if(!categoryId && !skladId){
            items = await Items.findAll()
        }
        if(categoryId && !skladId){
            items = await Items.findAll( {where:{categoryId}})
        }
        if(!categoryId && skladId){
            items = await Items.findAll( {where:{skladId}})
        }
        if(categoryId && skladId){
            items = await Items.findAll( {where:{categoryId, skladId}})
        }
        return res.json(items)
    }
}

module.exports = new itemController()