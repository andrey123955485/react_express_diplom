const ApiError = require('../error/ApiError')
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')
const {User} = require('../models/models')
const generateJwt = (id, login, role) => {
    return jwt.sign(
        { id, login, role }, 
        process.env.SECRET_KEY, // Задайте секретный ключ в .env файле
        { expiresIn: '24h' } // Время действия токена
    );
};
class userController {
    async login(req, res) {
        const { login, password } = req.body;

        // Проверяем, что поля не пустые
        if (!login || !password) {
            return next(ApiError.badRequest('Логин или пароль не указаны!'));
        }

        try {
            // Ищем пользователя в базе данных
            const user = await User.findOne({ where: { login } });
            if (!user) {
                return next(ApiError.badRequest('Пользователь не найден!'));
            }

            // Сравниваем хэш пароля
            const comparePassword = await bcrypt.compare(password, user.password);
            if (!comparePassword) {
                return next(ApiError.badRequest('Указан неверный пароль!'));
            }

            // Генерируем JWT токен
            const token = generateJwt(user.id, user.login, user.role);
            return res.json({ token });
        } catch (e) {
            return next(ApiError.internal('Ошибка при входе в систему'));
        }
    }

    async check(req, res, next) {
        const token = generateJwt(req.user.id, req.user.login, req.user.password, req.user.role)
        return res.json({token})
    }
}

module.exports = new userController()