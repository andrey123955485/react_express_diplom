const jwt = require('jsonwebtoken')
module.exports = function (req, res, next) {
    if (req.method === "OPTIONS"){
        next()
    }
    try{
        const token = req.header.authorization.split(' ')[1] // Bearer
        if(!token) {
          return  res.status(403).json({message: "Не авторизован"})
        }
        const decoded = jwt.verify(token, process.env.SERCRET_KEY)
        req.user = decoded
        next()
    } catch(e){
        res.status(403).json({message: "Не авторизован"})
    }
};